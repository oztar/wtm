'use strict'

const u     = require('util').format;
const name  = __filename.split(/[\\/]/).pop().replace('.js','');
const spawn = require('child_process').spawn;

const pkg = {
    author      : 'Alfredo',
    description : 'npm, module exec command npm in shell.',
    version     : '0.1',
    compatible  : '0.3.6'
};


const npmCon = {
    description : 'npm command',
    usage : 'npm [install|remove]',
    auto  : ['install','remove']  //or null
}
const npm = function(client,args){
    try{
	let com = args.join(' ');
	const child = spawn(com,{shell : true});
	this.emit(client,com);
	this.emit(client+'progress',0);
	child.stdout.setEncoding('utf8');
	child.stdout.on('data', data=>{
	    this.emit(client,u('%s',data));
	});
	child.stderr.setEncoding('utf8');
	child.stderr.on('data', data=>{
	    this.emit(client+'err',u('%s',data));
	});
	child.on('error', (data)=>{
	    this.emit(client+'err',u('Error %s',data));
	    	this.emit(client+'progress',-1);
	});
	child.on('close', ()=>{
	    this.emit(client+'progress',100);
	});
    }catch(e){
	this.emit(socketID+'err',u(e));
	this.emit(client+'progress',-1);
    }
}



module.exports = {
    pkg,
    command : {
	npm : npmCon
    },
    npm,
    autoload : false
}

'use strict'

const load = function(socketID){
    this.emit(socketID,'hola mundo internal load ');
}

const unload = function(socketID){

}

const methodName = function(){

}
const hola = function(req,res){
    res.send('hola mundo');
}
const info = function(){
    const json = {
        "paths": {
             "/hola" : {
                "get": {
                    "description": "Hola mundo",
                    "tags": ["texto"],
                    "produces": ["application/json"],
                    "parametres" : [{
                        "name" : "texto",
                        "description": "include en hello word",
                        "in": "formData",
                        "required": true,
                        "type": "string"
                    }],
                    "responses": {
                        "200": {
                            "description": "hello word"
                        }
                    }
                }
            }
        },             
        "definitions" : {
            "hola" : {
            "required" : ["texto"],
            "properties": {
                    "texto": {
                        "type": "string"
                    } 
                }            
            }
        },
        "responses": {},                
        "parameters": {
            "texto": {
                "name": "texto",
                "description": "cualquier texto",
                "in": "formData",
                "required": true,
                "type": "string"
            }
        },
        "securityDefinitions": {},
        "tags": []
    };
    return json;
}
module.exports = {
    load,
    unload,
    methodName,
    hola,
    info   
}
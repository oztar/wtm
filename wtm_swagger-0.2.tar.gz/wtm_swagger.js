'use strict'
const u     = require('util').format
const fs    = require('fs');
const path = require('path');
let swaggerUi; //librari swagger
const options = { root : __dirname+'/../node_modules/swagger-ui-dist/'}; 

const pkg = {
    author      : 'Alfredo Roman',
    license     : 'ISC',
    version     : '0.2',
    compatible  : '0.6.0',
    description : 'Module for swagger for APIs '
};
const nameCon = {
    description : 'Swagger module. create API REST + api swagger',
    usage : 'name [create|remove|disable|list|config|reload|load|unload]',
    auto  : ['create','remove','disable','list','config','reload','load','unload']  //or null
}
const listShow = ['show','load','drop'];
const errors = {
    PATH         : 'Path not found \r\n %s',
    FILE         : 'Path file or file error\r\n %s',
    USAGE        : 'Arguments error\r\n swagger {option} {api name}\r\n using help \t\n OR \t\n help usage swagger',
    USAGE_CONFIG : 'Swagger config [option] \r\n\t-\tshowr\n\t-\tload\n\t-\tdrop',
    USAGE_CFG    : 'Arguments error\r\n swagger config %s %s',
    UNDEFINED    : '%s internal error: \r\n %s\r\n%s',
    NCREATE      : 'No created API REST \r\n ejample\r\n\t swagger create  apiRest \r\n OR \r\n\t swagger list %s false \r\n\t\t - is for only list modules for folder "%s" api Rest',
    CREATE       : 'Need path modules REST ejample apiRest\ ',
    NPM          : 'Need install npm swagger-ui-express \t\n OR using console \t\n\t install module npm \t\n\t npm install swagger-ui-express ',
    NOTFOUND     : 'API REST not found'
};
let UIjson = {};
let methods = {};
let modules = {};
let json = {
  "info": {
    "title": "Web Terminal Module Swagger",
    "version": "1.0.1",
    "description": "A sample API Web Terminal swagger"
  },
  "host": "",
  "basePath": "/",
  "swagger": "2.0",
  "paths": {},
  "definitions": {},
  "responses": {},
  "parameters": {},
  "securityDefinitions": {},
  "tags": []
}
/*
  "basePath": "/",
  "swagger": "2.0",
  "paths": {
    "/": {
      "get": {
        "description": "Returns the homepage",
        "responses": {
          "200": {
            "description": "hello world"
          }
        }
      }
    },
    "/login": {
      "post": {
        "description": "Login to the application",
        "tags": ["Users", "Login"],
        "produces": ["application/json"],
        "parameters": [
          {
            "$ref": "#/parameters/username"
          },
          {
            "name": "password",
            "description": "User's password.",
            "in": "formData",
            "required": true,
            "type": "string"
          }
        ],
        "responses": {
          "200": {
            "description": "login",
            "schema": {
              "type": "object",
              "$ref": "#/definitions/Login"
            }
          }
        }
      }
    },
    "/users": {
      "get": {
        "description": "Returns users",
        "tags": ["Users"],
        "produces": ["application/json"],
        "responses": {
          "200": {
            "description": "users"
          }
        }
      },
      "post": {
        "description": "Returns users",
        "tags": ["Users"],
        "produces": ["application/json"],
        "parameters": [
          {
            "$ref": "#/parameters/username"
          }
        ],
        "responses": {
          "200": {
            "description": "users"
          }
        }
      }
    },
    "/hello": {
      "get": {
        "description": "Returns the homepage",
        "responses": {
          "200": {
            "description": "hello world"
          }
        }
      }
    }
  },
  "definitions": {
    "Login": {
      "required": ["username", "password"],
      "properties": {
        "username": {
          "type": "string"
        },
        "password": {
          "type": "string"
        },
        "path": {
          "type": "string"
        }
      }
    }
  },
  "responses": {},
  "parameters": {
    "username": {
      "name": "username",
      "description": "Username to use for login.",
      "in": "formData",
      "required": true,
      "type": "string"
    }
  },
  "securityDefinitions": {},
  "tags": [
    {
      "name": "Users",
      "description": "User management and login"
    },
    {
      "name": "Login",
      "description": "Login"
    },
    {
      "name": "Accounts",
      "description": "Accounts"
    }
  ]
}

/*
 CONFIGURATION sub module
*/
const _config = function (socketID,args){
 try {
    this['swagger_CFG_'+args[2]](socketID,args);
  }catch(e){
    this.emit(socketID+'err',u(e));
  }
}

const CFG_show = function (socketID,args){
  this.emit(socketID,u('Configuracion de swagger API REST'));
  this.emit(socketID,u(this.options.swaggerConfig));
}
const CFG_load = function (socketID,args){
	if( args[3] === undefined){ 
    this.emit(socketID+'err', u(errors['USAGE_CFG'],'load','{json name}'));
    return;
  }
  try {
    const config = require(args[3]);
    this.options.swaggerConfig = config;
    this.emit(socketID, u('Load File  "%s" config, ist ok',args[3]));
  }catch(e){
    this.emit(socketID+'err', u(errors['FILE'],e));
  }
}
const CFG_drop = function (socketID,args){
	if( args[3] === undefined){ 
    this.emit(socketID+'err', u(errors['USAGE_CFG'],'drop','now'));
    return;
  }
  if( args[3] != 'now'){ 
    this.emit(socketID+'err', u(errors['USAGE_CFG'],'drop','now'));
    return;
  }
  this.options.swaggerConfig = {};
  this.emit(socketID, u('Drop configuration API REST'));
}
/*
  BASE command
*/
const swagger = function(socketID,args){
    try{
	if( this['swagger__'+args[1]] === undefined){
	    this.emit(socketID+'err', u(errors['USAGE']))
	    return;
	}
	if( args[2] === undefined){ 
	    this.emit(socketID+'err', u(errors['USAGE']));
	    return;
	}

	this['swagger__'+args[1]](socketID,args);
    }catch(e){
	this.emit(socketID+'err',u(e));
   }
}

/* 
  SUB COMANNDS 
*/
const _reload = function(socketID,args){
  if( args[3] === undefined){     
    this.emit(socketID+'err', u('USAGE swagger reload {api name} [module|all] {module name}'));
    return;
  }

  if( args[3] == "module" && args[4] !== undefined){ 
    this['swagger_unloadModule'](socketID,args[2],args[4]); 
    this['swagger_loadModule'](socketID,args[2],args[4]);  
    
  }else if( args[3] == 'all'){

    for( let nameModule in modules[ args[2] ]){
      this['swagger_unloadModule'](socketID,args[2],nameModule); 
      this['swagger_loadModule'](socketID,args[2],nameModule); 
    }
  }
}
const _load = function(socketID,args){
  if( args[3] === undefined){ 
    this.emit(socketID+'err', u(errors['USAGE']));
    return;
  }

  if( args[3] == "module" && args[4] !== undefined){ 
    this['swagger_loadModule'](socketID,args[2],args[4]);     
  }
}
const _unload = function(socketID,args){
  if( args[3] === undefined){ 
    this.emit(socketID+'err', u(errors['USAGE']));
    return;
  }

  if( args[3] == "module" && args[4] !== undefined){ 
    this['swagger_unloadModule'](socketID,args[2],args[4]);     
  }
}
const _list = function(socketID,args){

    const path = __dirname + '/' + args[2];
    let table = {
	title : 'List modules API REST '+ path,
	head  : ['Name ','Load ','Methods'],
	tableid : false,
	'table' : {}
    };
    if( !this.options.swaggerApis[args[2]] && args[3] != 'false'){
	this.emit(socketID+'err', u(errors['NCREATE'],args[2],args[2]));
	return;
    }
    if( !fs.existsSync(path) ){
	this.emit(socketID+'err',u(errors['PATH'],path))
	return;
    }
    fs.readdir( path, (e,files) =>{
	if (e){
	    this.emit(socketID+'err', u(errors['UNDEFINED'],'swagger fs',e,''));
	}else{	    	
	    for( let i in files){
		let file = files[i];
		table.table[file] = { 'Name' : file ,'Load' : this.f.color('no','red'),'Methods' : ''}
		if( args[3] != 'false'){
		    if( modules[args[2]][file]){
			    table.table.file.Load = this.f.color('load','limegreen')
		    }
		}
	    }
	    this.emit('tablef',socketID,table);
	}
    });

    this['swagger_testApi'](socketID,true,args);
}


const _remove = function(socketID,args){  
  this.emit(socketID,'not remove, its disable endpoint');
  this['swagger__disable'](socketID,args);    
}
const _disable  = function(socketID,args){  
    //si no envia argumento no hacemos nada

  if( !this.options.swaggerApis[ args[2]] ){
    this.emit(socketID,'La API esta deshabilitada. No se puede volver a deshabilitar');
  }

  try {
    for( let nameModule in modules[ args[2] ]){
      this['swagger_unloadModule'](socketID,args[2],nameModule); 
    }
  }catch(e){
    this.emit(socketID+'err', u(errors['UNDEFINED'],'SWAGGER DISABLE','Modules unload',e));
    return;
  }

  let pasa = 1;
  if( this.options.swaggerApis[args[2]] !== undefined){    
    this['swagger_deleteWebs'](args[2]);
    pasa = 0;
  }
  
  if( pasa == 0){
    this.emit(socketID, u('Borrado api',args[2]));
  }else{
    this.emit(socketID+'err', u(errors['NOTFOUND']));
  }
}

/*
  CREATE API REST 
*/
const _create  = function(socketID,args){  
  this.emit(socketID, u('Create API REST'));

  let uid = true;
  if( args[3] !== undefined){
    uid = ( "true" === args[3]);
  }

  //load library  
  if( uid ){//solamente necesitamos swagger-ui si queremo tener UI de pruebas
    try {
      swaggerUi = require('swagger-ui-express');
    }catch(e){
      this.emit(socketID+'err',u(errors['NPM']));
      return;      
    }
  }
  
  if( this.options.swaggerApis[args[2]] !== undefined){//existe
    if( this.options.swaggerApis[args[2]] ){// es true => esta habilitada
      this.emit(socketID+'err',u('error de app express exist'));
      return;
    }
  }
  if( this['swagger_testApi'](socketID,false,args)){

    //cargamos los modulos 
    const path = __dirname + '/' + args[2];    
    modules[args[2]] = {};
    methods[args[2]] = {};
    UIjson[args[2]]  = {...json};
    UIjson[args[2]].host = this.options.publicip + ":" + this.options.port;
    UIjson[args[2]].basePath = '/'+ args[2];

    //creamos el webhook
    this['swagger__webhook'](socketID,args[2],uid);

    for( let nameModule in this.options.swaggerConfig[args[2]] ){
      //cargamos los modulos      
      if(this.options.swaggerConfig[args[2]][nameModule] ){         

        if( fs.existsSync(path+ '/' + nameModule + '.js') ){

          this['swagger_loadModule'](socketID,args[2],nameModule);

        }
        else{
          this.emit(socketID+'err', u(errors['File'],nameModule));
        }
      }else{
        this.emit(socketID, u('Module\t\t'+nameModule+'\t\tfalse'));
 
      }
    }

    this.options.swaggerApis[ args[2] ]  = true;	
  }
}

/*
  INSERTNAL COMANDS
*/
const testApi =  function(socketID,r,args){
  //const path = __dirname + '/' + args[2];
  if( this.options.swaggerConfig[args[2]] === undefined){
    this.emit(socketID+'err',u('error: API not configuration parametres'));
    return false;
  }


  const path = __dirname + '/' + args[2];
  if( fs.existsSync(path) ){
    if(r){
      this.emit(socketID, this.f.color('API Path OK '+path,'limegreen'));
    }
  }else{
    this.emit(socketID+'err',u(errors['PATH'],path));
    return false;
  }


  if(r){
    this.emit(socketID, this.f.color('API Json configuration','limegreen'));
  }
  try {
    for( let module in this.options.swaggerConfig[args[2]] ){
      if( this.options.swaggerConfig[args[2]][module]){
        if( r){
         this.emit(socketID, u("\t%s\t%s",module,'for load'));    
        }
      }else{
        if( r){
          this.emit(socketID, u("\t%s\t%s",module,'not requied'));    
        }
      }

    }
    if( r){
      this.emit(socketID, this.f.color('Structure configuration ok','limegreen'));       
    }
    return true;
  }catch(e){
      this.emit(socketID, this.f.color('Structure configuration error','red'));
      return false;  
  }
}

const _webhook = function(socketID,apiName,uid){
  try {
    if ( this.options.swaggerApis[ apiName ] === undefined ){
      let url = '/' + apiName + '/*';
      this.options.app.all(url, (req,res,next)=>{        
        if ( !this.options.swaggerApis[ apiName ]){
          next();
          return;
        }
        
        /* swagger UI */
        if(uid== true && req.params[0] == 'swagger'){
          res.send(swaggerUi.generateHTML( UIjson[ apiName ] ));
          return;

        }else if( uid== true &&  req.params[0] == 'swagger-ui-init.js') {
          let javascriptFiles = swaggerUi.serveFiles(  UIjson[ apiName ]);          
          javascriptFiles[0](req,res);

        }else if(uid== true &&  /^swagger-([a-z0-9\.\-]+)$/i.test(req.params[0]) ){          
          res.sendFile(req.params[0], options, function (err) {
              if (err) {
                  next(err);
              }
          });
        /* swagger UI */  

        /*swagger modules - your modules*/ 
        }else if( /^[a-z0-9]+$/i.test(req.params[0]) ){
          try {
              const method = apiName + '/' + req.params[0];
              //console.log({ url, "parameters" : req.params, "enable API" : this.options.swaggerApis[ apiName],apiName,method, methods,"module": method[ method ]});
              if(  methods[ method ] !== undefined ){ 
                let name = methods[ method ].module;
                this.module[ name ][ req.params[0] ](req,res);                                
              }else{  
                this.emit(socketID,u('Error API "%s/%s"\r\n not method or module ',apiName,req.params[0]));                
                next();
              }
            }catch(e){
              this.emit(socketID,u('Error API "%s/%s"\r\n%s ',apiName,req.params[0],e));
              next();
            }
          }
        });
        /*swagger modules - your modules*/ 



      if( uid){
        this.emit(socketID, u('swagger  UI: \t\tCreated %s', this.options.publicip + ":" + this.options.port + '/' + apiName + '/swagger' )); 
      }
      this.emit(socketID, u('web hook: \t\tCreated %s', this.options.publicip + ":" + this.options.port + url )); 
    }  
  }catch(e){
    this.emit(socketID+'err', u('webhook error \r\n %s',e)); 
  }
}

const deleteWebs = function(web){
  //borramos WEBs 
  this.options.swaggerApis[ web ]= false;
  delete methods[ web ];
  delete modules[ web ];
  delete UIjson[ web ];
}

const loadModule = function(socketID,api,nameModule){
  this._load_module(socketID,nameModule,this.options.path+api+'/',false);          
          
  modules[api][nameModule] = true;//indicamos que se ha cargado en memoria

  const moduleJson = this.module[ nameModule ].info();
  UIjson[ api ].paths =  {...UIjson[ api ].paths, ...moduleJson.paths};
  UIjson[ api ].definitions  =  {...UIjson[ api ].definitions, ...moduleJson.definitions};
  UIjson[ api ].responses     =  {...UIjson[ api ].responses, ...moduleJson.responses};
  UIjson[ api ].parameters  =  {...UIjson[ api ].parameters, ...moduleJson.parameters};
  UIjson[ api ].securityDefinitions  =  {...UIjson[ api ].securityDefinitions, ...moduleJson.securityDefinitions};
  UIjson[ api ].tags  =  [...UIjson[ api ].tags, ...moduleJson.tags];
 
    //alta methods 
  for(var pathName in moduleJson.paths){
    methods[ api+pathName ] = { module : nameModule};
  }
}

const unloadModule = function(socketID,api,nameModule){
  const moduleJson = this.module[ nameModule ].info();

  this._unload_module(socketID,nameModule,this.options.path+api+'/');                   
  delete modules[ api ][nameModule];

  for(var pathName in moduleJson.paths){
    delete UIjson[ api ].paths[pathName];
    delete methods[ api+'/'+pathName ];
  }
}
/* load and unload module */
const load = function(){

    if( this.options.swaggerConfig === undefined){      
        this.options.swaggerConfig = { apis : {}};
    } 
    if( this.options.swaggerApis === undefined){      
      this.options.swaggerApis = {};
  } 

    this.options.list_auto_command['swagger config'] = listShow;
    this.options.list_auto_command['swagger config drop'] = ['now'];
    
    this.emit('send_autocomplete','swagger config',this.options.list_auto_command['swagger config']);
    this.emit('send_autocomplete','swagger config drop',this.options.list_auto_command['swagger config drop']);
}

const unload = function(){
    for( let apiName in this.options.swaggerApis){      
      const path = __dirname + '/' + apiName;

      deleteWebs(apiName);
      //quitamos modulos
      for( let nameModule in modules[web]){     
        this.unloadModule(socketID,nameModule);        
      }
    }

    delete this.options.list_auto_command['swagger config'];
    delete this.options.list_auto_command['swagger config drop'];

    this.emit('del_autocomplete','swagger config');
    this.emit('del_autocomplete','swagger config drop');

}


module.exports = {
    command : {
	    swagger : nameCon
    },
    pkg,
    swagger,
    _create,
    _remove,
    _reload,
    _load,
    _unload,
    _disable,
    _list,
    _webhook,
    _config,
    CFG_show,
    CFG_load,
    CFG_drop,
    testApi,   
    deleteWebs,
    loadModule,
    unloadModule, 
    load,
    unload,
    autoload : true
};

